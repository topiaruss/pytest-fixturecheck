# pytest-fixturecheck

A pytest plugin to validate fixtures before they're used in tests.

## The Problem

In complex test suites, particularly when using Django or other ORMs, fixtures can silently break due to model changes. For example:

- A database model field gets renamed, but fixtures that create test data aren't updated
- A fixture depends on another fixture that changes its return structure
- Schema migrations occur but fixture setup code isn't updated

This causes confusing test failures because the error appears in the test using the fixture, not in the fixture itself. It can be hard to diagnose that a broken fixture is the culprit, not the actual test logic.

## Installation

```bash
pip install pytest-fixturecheck
```

## Usage

### Basic Usage

Add the `@fixturecheck` decorator to any fixture you want to validate:

```python
from pytest_fixturecheck import fixturecheck

@fixturecheck
@pytest.fixture
def author():
    return Author.objects.create(name="Marian Brook")
```

This will execute the fixture once during collection time to verify it can run without errors.

### Django Models Example

With Django models, you can use the Django-specific handler to validate model field access:

```python
from pytest_fixturecheck import fixturecheck
from pytest_fixturecheck.django import validate_model_fields

@fixturecheck(validate_model_fields)
@pytest.fixture
def book(author, publisher):
    return Book.objects.create(
        title="Echoes of the Riverbank",
        author=author,
        publisher=publisher,
    )
```

## How It Works

The plugin works by:

1. Discovering fixtures marked with `@fixturecheck`
2. During test collection, executing those fixtures in isolation to verify they work
3. Catching and reporting errors before any tests run
4. Displaying clear error messages pointing directly to fixture issues

## License

MIT License
