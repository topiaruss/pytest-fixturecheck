#!/usr/bin/env python

# This file is kept only for backward compatibility
# The actual configuration is in pyproject.toml

from setuptools import setup

setup()
